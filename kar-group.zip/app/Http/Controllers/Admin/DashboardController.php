<?php

namespace App\Http\Controllers\Admin;

use App\Exports\EntriesExport;
use App\Http\Controllers\Controller;
use App\Models\Branch;
use App\Models\Entries;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //



      $entries =     Entries::select('client_name','created_at')
        ->groupBy(DB::raw('Date(created_at)'))->
        orderBy('created_at', 'DESC')
       ->get();
        $branches = Branch::orderBy('sort','ASC')->get();
        $date = Carbon::now();

        $month =  $date->month();

       // return $month;



         $totals  = Entries::orderBy('id','ASC')->count();
            $months  = Entries::
  whereMonth('created_at',$month)

         ->orderBy('id','ASC')->count();

          $days  = Entries::
      whereDate('created_at','=',$date)


                ->orderBy('id','ASC')->count();

        return  view('admin.dashboard.dashoard',compact('branches','totals','months','days','entries'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function get_student_data(Request $request)
    {

   $date =   Carbon::parse($request->current_date)->format('Y-m-d');
        return Excel::download(new EntriesExport($date), $date.'_list.xlsx');
    }


    public function downloads($date)
    {

  // $date =   Carbon::parse($request->current_date)->format('Y-m-d');
        return Excel::download(new EntriesExport($date), $date.'_list.xlsx');
    }
}
