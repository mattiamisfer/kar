<?php $__env->startSection('title', 'About Us'); ?>

<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>
<section class="inner-page">
<div class="container">
</div><!--container-->
</section><!--inner-page-->

<div class="clearfix"></div>
<section class="logo-section">
<div class="container">
<h4 class="inner-page-title">ABOUT US</h4>

<div class="row newsdetail">
<div class="col-md-4">
<figure>
<img width="360" height="250" src="<?php echo e($pages->logo); ?>" alt="" class="img-responsive"/>
</figure>
</div><!--col-md-4-->
<div class="col-md-8">


<?php echo $pages->content; ?>

</div><!--col-md-8-->
</div><!--row-->



</div><!--container-->
</section> <!--logo-section-->
<div class="clearfix"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\affity\Desktop\New folder\seagul__\kar-group\resources\views/web/about.blade.php ENDPATH**/ ?>