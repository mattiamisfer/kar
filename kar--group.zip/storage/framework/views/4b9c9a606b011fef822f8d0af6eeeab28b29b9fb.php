<DOCTYPE html>
    <html lang="en-US">
      <head>
      <meta charset="utf-8">
      </head>
      <body>
      <h2>                                                                                  Hi <?php echo e($data['name']); ?>, we’re glad you’re here! Following are your account details: <br>

     <strong> Email : <?php echo e($data['email']); ?></strong>
     <strong> Passowrd : <?php echo e($data['password']); ?></strong>

     <p>Click here to login <a target="_blank" href="https://www.seagullgroup.in/branch/">Login</a></p>
 </body>
 </html>
<?php /**PATH C:\Users\affity\Desktop\New folder\seagul__\kar-group\resources\views/email/templade.blade.php ENDPATH**/ ?>