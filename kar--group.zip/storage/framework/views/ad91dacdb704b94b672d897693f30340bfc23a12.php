

         <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <script>document.write(new Date().getFullYear())</script> © Kar Group.
                    </div>
                    <div class="col-sm-6">
                        <div class="text-sm-end d-none d-sm-block">
                            Design & Develop by <a href="#!" class="text-decoration-underline">Affinity Interactive</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
<?php /**PATH C:\Users\affity\Desktop\New folder\seagul__\kar-group\resources\views/admin/footer.blade.php ENDPATH**/ ?>