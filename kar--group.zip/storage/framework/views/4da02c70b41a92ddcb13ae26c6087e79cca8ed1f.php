<?php $__env->startSection('headerJs'); ?>
<link href="<?php echo e(asset('web/lightbox/dist/css/lightbox.min.css')); ?>" rel="stylesheet" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>
<section class="inner-page">
<div class="container">
</div><!--container-->
</section><!--inner-page-->

<div class="clearfix"></div>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<section class="logo-section">
<div class="container">
<h4 class="inner-page-title"><?php echo e($category->title); ?></h4>

<?php $__currentLoopData = $category->sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="row">
<div class="col-md-8 col-md-offset-2">
<div class="row">


<div class="col-md-8 col-md-offset-4">
<div class="news-img" style="width:250px;">
<a href="<?php echo e($sector->url); ?>" target="_blank"><img src="<?php echo e($sector->logo); ?>" class="img-responsive"/></a>
</div><!--news-img-->
<hr class="red-hr">

<?php echo $sector->content; ?>

<a href="<?php echo e($sector->url); ?>" class="btn btn-primary" target="_blank">VISIT OUR WEBSITE</a>
<div class="clearfix"></div>
<br /><br />
<div class="row">

    <?php $__currentLoopData = explode(',', $sector->gallery); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-3">
<a data-lightbox="example-1" rel="example_group_<?php echo e($key); ?>"  id="<?php echo e($key); ?>"  class="zoom galleryZoomIcon example-image-link fancybox-thumb clickFunc" data-fancybox-type="image" data-thumbnail="" data-fancybox-group="gallery" data-fancybox="fancybox" href="<?php echo e($info); ?>">
        <img src="<?php echo e($info); ?>" alt="" width="100%" class="example-image img-responsive" height="237" class="" style="display: inline-block;">
        </a>
</div><!--col-md-3-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--row-->
</div><!--col-md-8-->
</div><!--row-->

</div> <!--col-md-8 col-md-offset-2-->
</div><!--row-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--container-->
</section> <!--logo-section-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="clearfix"></div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerScript'); ?>
<script src="<?php echo e(asset('web/lightbox/dist/js/lightbox-plus-jquery.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\affity\Desktop\New folder\seagul__\kar-group\resources\views/web/read-sector.blade.php ENDPATH**/ ?>