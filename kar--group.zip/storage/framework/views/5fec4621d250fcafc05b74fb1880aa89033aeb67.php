<?php $__env->startSection('content'); ?>

 <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <?php if(Session::has('success')): ?>

                            <div class="alert alert-success" role="alert">
                              <?php echo e(Session::get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(Session::has('failure')): ?>
                            <div class="alert alert-danger" role="alert">
                              <?php echo e(Session::get('failure')); ?>

                            </div>
                         <?php endif; ?>
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                <h4 class="mb-sm-0 font-size-18">DAILY UPDATES ON ACCOUNT MANAGEMENT...</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                                        <li class="breadcrumb-item active">Account Management</li>
                                    </ol>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">

                                <div class="card-body p-4">

                                    <form action="<?php echo e(route('user.products.store')); ?>" method="POST">

                                        <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div>
                                                <div class="mb-3">
                                                    <label for="example-text-input" class="form-label">DT. OF RECEIPT OF
                                                        REQUIREMENT</label>
                                                    <input class="form-control" type="date" name="receipt_requirement_date" value="Artisanal kale"
                                                        id="example-text-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-search-input" class="form-label">CLIENT</label>
                                                    <input class="form-control" type="text" name ="client_name" value=""
                                                        id="example-search-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-email-input" class="form-label">COUNTRY</label>
                                                    

                                                        <select   class="form-control" name="country_name" id="example-email-inpu">
                                                            <option value="">Choose</option>

                                                            <option value="India">India</option>
                                                            <option value="Saudi Arabia">Saudi Arabia</option>
                                                            <option value="UAE">UAE</option>
                                                            <option value="Bahrain">Bahrain</option>
                                                            <option value="Kuwait">Kuwait</option>
                                                            <option value="Oman">Oman</option>
                                                            <option value="Iraq">Iraq</option>
                                                            <option value="Usa">Usa</option>
                                                            <option value="Europe(Continent)">Europe(Continent)</option>
                                                            <option value="Others">Others</option>


                                                        </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-url-input" class="form-label">PROJECT</label>
                                                    <input class="form-control" type="text"  name ="project_name" value=""
                                                        id="example-url-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-email-input"
                                                        class="form-label">POSITIONS</label>
                                                    <input class="form-control" type="text" name="postitions" value=""
                                                        id="example-email-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-email-input" class="form-label">NO. OF
                                                        REQUIREMENTS</label>
                                                    <input class="form-control" type="number" name="num_of_requirement"  value=""
                                                        id="example-email-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-email-input" class="form-label">SOURCE</label>
                                                    <input class="form-control" type="text" name="source" value=""
                                                        id="example-email-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-email-input" class="form-label">CVS
                                                        SHARED</label>
                                                    <input class="form-control" type="text" name="cvs_shared" value=""
                                                        id="example-email-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input"
                                                        class="form-label">SHORTLISTED</label>
                                                    <input class="form-control" type="text" name="short_list" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">LINED UP FOR
                                                        INTERVIEW</label>
                                                    <input class="form-control" type="text"  name="line_up_for_interview" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">INTERVIEW
                                                        LOCATION</label>
                                                    <input class="form-control" type="text" name="interview_location" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">DATE OF
                                                        INTERVIEW</label>
                                                    <input class="form-control" type="date" name="date_of_interview" value=""
                                                        id="example-date-input">
                                                </div>

                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="mt-3 mt-lg-0">
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">SELECTED</label>
                                                    <input class="form-control" type="text" name="selected" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">ACCEPTED</label>
                                                    <input class="form-control" type="text" name="accepted" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">OFFER RECEIVED
                                                    </label>
                                                    <input class="form-control" type="text" name="offer_received" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">UNDER MEDICAL
                                                    </label>
                                                    <input class="form-control" type="text" name="under_medical" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">MEDICAL FIT
                                                    </label>
                                                    <input class="form-control" type="text" name="medical_fit" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">VISA UNDER
                                                        PROCESS </label>
                                                    <input class="form-control" type="text" name="visa_under_proccess" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">VISA RECEIVED</label>
                                                    <input class="form-control" type="text" name="visa_received" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">ECR STATUS</label>
                                                    <input class="form-control" type="text" name="ecr_status" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">SCHEDULED</label>
                                                    <input class="form-control" type="date" name="scheduled" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">DEPLOYED ON  </label>
                                                    <input class="form-control" type="date" name="deployed_on" value=""
                                                        id="example-date-input">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">REMARKS</label>
                                                    <input class="form-control" type="text" name="remarks" value=""
                                                        id="example-date-input">

                                                        <textarea class="form-control" name="remarks"></textarea>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="example-date-input" class="form-label">ATTENDED </label>
                                                    <input class="form-control" type="text" name="attended" value=""
                                                        id="example-date-input">
                                                </div>



                                            </div>

                                        </div>
                                        <div class="mb-3">

                                            <input type="submit" class="form-control btn btn-success" value="Submit"/>

                                        </div>

                                    </div>

                                    <form>
                                </div>
                            </div>
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                    <!-- Start row -->

                    <!-- End row -->


                    <!-- end row -->


                    <!-- end row -->

                </div> <!-- container-fluid -->
            </div>
            <!-- END layout-wrapper -->


            <!-- Right Sidebar -->
            <div class="right-bar">
                <div data-simplebar class="h-100">
                    <div class="rightbar-title d-flex align-items-center bg-dark p-3">

                        <h5 class="m-0 me-2 text-white">Theme Customizer</h5>

                        <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                            <i class="mdi mdi-close noti-icon"></i>
                        </a>
                    </div>

                    <!-- Settings -->
                    <hr class="m-0" />

                    <div class="p-4">
                        <h6 class="mb-3">Layout</h6>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="layout" id="layout-vertical"
                                value="vertical">
                            <label class="form-check-label" for="layout-vertical">Vertical</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="layout" id="layout-horizontal"
                                value="horizontal">
                            <label class="form-check-label" for="layout-horizontal">Horizontal</label>
                        </div>

                        <h6 class="mt-4 mb-3 pt-2">Layout Mode</h6>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="layout-mode" id="layout-mode-light"
                                value="light">
                            <label class="form-check-label" for="layout-mode-light">Light</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="layout-mode" id="layout-mode-dark"
                                value="dark">
                            <label class="form-check-label" for="layout-mode-dark">Dark</label>
                        </div>

                        <h6 class="mt-4 mb-3 pt-2">Layout Width</h6>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="layout-width" id="layout-width-fuild"
                                value="fuild" onchange="document.body.setAttribute('data-layout-size', 'fluid')">
                            <label class="form-check-label" for="layout-width-fuild">Fluid</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="layout-width" id="layout-width-boxed"
                                value="boxed"
                                onchange="document.body.setAttribute('data-layout-size', 'boxed'),document.body.setAttribute('data-sidebar-size', 'sm')">
                            <label class="form-check-label" for="layout-width-boxed">Boxed</label>
                        </div>

                        <h6 class="mt-4 mb-3 pt-2">Layout Position</h6>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="layout-position"
                                id="layout-position-fixed" value="fixed"
                                onchange="document.body.setAttribute('data-layout-scrollable', 'false')">
                            <label class="form-check-label" for="layout-position-fixed">Fixed</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="layout-position"
                                id="layout-position-scrollable" value="scrollable"
                                onchange="document.body.setAttribute('data-layout-scrollable', 'true')">
                            <label class="form-check-label" for="layout-position-scrollable">Scrollable</label>
                        </div>

                        <h6 class="mt-4 mb-3 pt-2">Topbar Color</h6>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="topbar-color" id="topbar-color-light"
                                value="light" onchange="document.body.setAttribute('data-topbar', 'light')">
                            <label class="form-check-label" for="topbar-color-light">Light</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="topbar-color" id="topbar-color-dark"
                                value="dark" onchange="document.body.setAttribute('data-topbar', 'dark')">
                            <label class="form-check-label" for="topbar-color-dark">Dark</label>
                        </div>

                        <h6 class="mt-4 mb-3 pt-2 sidebar-setting">Sidebar Size</h6>

                        <div class="form-check sidebar-setting">
                            <input class="form-check-input" type="radio" name="sidebar-size" id="sidebar-size-default"
                                value="default" onchange="document.body.setAttribute('data-sidebar-size', 'lg')">
                            <label class="form-check-label" for="sidebar-size-default">Default</label>
                        </div>
                        <div class="form-check sidebar-setting">
                            <input class="form-check-input" type="radio" name="sidebar-size" id="sidebar-size-compact"
                                value="compact" onchange="document.body.setAttribute('data-sidebar-size', 'md')">
                            <label class="form-check-label" for="sidebar-size-compact">Compact</label>
                        </div>
                        <div class="form-check sidebar-setting">
                            <input class="form-check-input" type="radio" name="sidebar-size" id="sidebar-size-small"
                                value="small" onchange="document.body.setAttribute('data-sidebar-size', 'sm')">
                            <label class="form-check-label" for="sidebar-size-small">Small (Icon View)</label>
                        </div>

                        <h6 class="mt-4 mb-3 pt-2 sidebar-setting">Sidebar Color</h6>

                        <div class="form-check sidebar-setting">
                            <input class="form-check-input" type="radio" name="sidebar-color" id="sidebar-color-light"
                                value="light" onchange="document.body.setAttribute('data-sidebar', 'light')">
                            <label class="form-check-label" for="sidebar-color-light">Light</label>
                        </div>
                        <div class="form-check sidebar-setting">
                            <input class="form-check-input" type="radio" name="sidebar-color" id="sidebar-color-dark"
                                value="dark" onchange="document.body.setAttribute('data-sidebar', 'dark')">
                            <label class="form-check-label" for="sidebar-color-dark">Dark</label>
                        </div>
                        <div class="form-check sidebar-setting">
                            <input class="form-check-input" type="radio" name="sidebar-color" id="sidebar-color-brand"
                                value="brand" onchange="document.body.setAttribute('data-sidebar', 'brand')">
                            <label class="form-check-label" for="sidebar-color-brand">Brand</label>
                        </div>

                        <h6 class="mt-4 mb-3 pt-2">Direction</h6>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="layout-direction"
                                id="layout-direction-ltr" value="ltr">
                            <label class="form-check-label" for="layout-direction-ltr">LTR</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="layout-direction"
                                id="layout-direction-rtl" value="rtl">
                            <label class="form-check-label" for="layout-direction-rtl">RTL</label>
                        </div>

                    </div>

                </div> <!-- end slimscroll-menu-->
            </div>
            <!-- /Right-bar -->

            <!-- Right bar overlay-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\affity\Desktop\New folder\seagul__\seagul\resources\views/user/form/add.blade.php ENDPATH**/ ?>