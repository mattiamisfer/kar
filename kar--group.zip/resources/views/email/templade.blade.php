<DOCTYPE html>
    <html lang="en-US">
      <head>
      <meta charset="utf-8">
      </head>
      <body>
      <h2>                                                                                  Hi {{$data['name']}}, we’re glad you’re here! Following are your account details: <br>

     <strong> Email : {{$data['email']}}</strong>
     <strong> Passowrd : {{$data['password']}}</strong>

     <p>Click here to login <a target="_blank" href="https://www.seagullgroup.in/branch/">Login</a></p>
 </body>
 </html>
